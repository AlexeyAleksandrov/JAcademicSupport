package io.github.alexeyaleksandrov.jacademicsupport.controllers.rest.rpd;

import io.github.alexeyaleksandrov.jacademicsupport.dto.rpd.indicator.IndicatorDto;
import io.github.alexeyaleksandrov.jacademicsupport.dto.rpd.indicator.UpdateIndicatorRequest;
import io.github.alexeyaleksandrov.jacademicsupport.services.competency.CompetencyAchievementIndicatorService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import jakarta.validation.Valid;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Optional;

import io.github.alexeyaleksandrov.jacademicsupport.dto.rpd.indicator.CreateIndicatorRequest;

@RestController
@AllArgsConstructor
@RequestMapping("api/competencies/{competencyNumber}/indicators")
public class IndicatorRestController {
    private final CompetencyAchievementIndicatorService service;

    @PostMapping
    public ResponseEntity<IndicatorDto> createCompetencyAchievementIndicator(
            @PathVariable("competencyNumber") String competencyNumber,
            @Valid @RequestBody CreateIndicatorRequest createRequest) {
        
        // Check if competency exists
        if (!service.competencyExists(competencyNumber)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Competency not found");
        }
                
        // Check if indicator with this number already exists
        if (service.indicatorExists(createRequest.getNumber())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Indicator with this number already exists");
        }
        
        var savedIndicator = service.createIndicator(competencyNumber, createRequest);
        
        return ResponseEntity
                .created(URI.create("/api/competencies/" + competencyNumber + "/indicators/" + savedIndicator.getId()))
                .body(service.convertToDto(savedIndicator));
    }

    @PostMapping("/{number}/keywords")
    public ResponseEntity<IndicatorDto> createKeywordsForCompetencyAchievementIndicator(@PathVariable("number") String number) {
        var indicator = service.createKeywordsForIndicator(number);
        return ResponseEntity.ok(service.convertToDto(indicator));
    }

    @GetMapping
    public ResponseEntity<List<IndicatorDto>> getAllIndicators(@PathVariable("competencyNumber") String competencyNumber) {
        List<IndicatorDto> indicatorDtos = service.findAllByCompetencyNumber(competencyNumber).stream()
                .map(service::convertToDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(indicatorDtos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<IndicatorDto> getIndicatorById(@PathVariable Long id) {
        return service.findByIdOptional(id)
                .map(service::convertToDto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/number/{number}")
    public ResponseEntity<IndicatorDto> getIndicatorByNumber(@PathVariable("number") String number) {
        return service.findByNumberOptional(number)
                .map(service::convertToDto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<IndicatorDto> updateIndicatorById(@PathVariable Long id, @Valid @RequestBody UpdateIndicatorRequest updateRequest) {
        var updated = service.updateIndicatorById(id, updateRequest);
        return ResponseEntity.ok(service.convertToDto(updated));
    }

    @PutMapping("/number/{number}")
    public ResponseEntity<IndicatorDto> updateIndicatorByNumber(@PathVariable("number") String number, @Valid @RequestBody UpdateIndicatorRequest updateRequest) {
        var updated = service.updateIndicatorByNumber(number, updateRequest);
        return ResponseEntity.ok(service.convertToDto(updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteIndicatorById(@PathVariable Long id) {
        if (!service.indicatorExistsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Indicator not found");
        }
        service.deleteIndicatorById(id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/number/{number}")
    public ResponseEntity<Void> deleteIndicatorByNumber(@PathVariable("number") String number) {
        if (!service.indicatorExists(number)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Indicator not found");
        }
        service.deleteIndicatorByNumber(number);
        return ResponseEntity.noContent().build();
    }
}
