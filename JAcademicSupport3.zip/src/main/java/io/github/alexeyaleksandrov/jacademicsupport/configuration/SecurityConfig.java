package io.github.alexeyaleksandrov.jacademicsupport.configuration;

import io.github.alexeyaleksandrov.jacademicsupport.security.JwtAuthenticationFilter;
import io.github.alexeyaleksandrov.jacademicsupport.services.CustomUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@Profile("!local")  // Использовать для всех профилей кроме 'local' (например, для 'prod')
public class SecurityConfig {

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(customUserDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/auth/**").permitAll()
                        .requestMatchers("/error").permitAll()
                        // Actuator health endpoints должны быть доступны без аутентификации
                        // для Docker healthcheck и deployment verification
                        .requestMatchers("/actuator/health/**").permitAll()
                        .requestMatchers("/actuator/health").permitAll()
                        .requestMatchers("/actuator/info").permitAll()
                        // Scheduler cron job endpoint для автоматической загрузки вакансий
                        .requestMatchers("/vac/by-saved-searches").permitAll()
                        // DST pipeline admin endpoints
                        .requestMatchers("/api/admin/dst/**").permitAll()
                        // DST query endpoints (read-only, used by frontend)
                        .requestMatchers("/api/dst/**").permitAll()
                        // EXP & FC viewer endpoints (read-only, used by foresight.html)
                        .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/foresights/**").permitAll()
                        .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/expert-opinions/**").permitAll()
                        // Curriculum / Discipline / Coverage - READ-ONLY for public (used by curriculum.html)
                        .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/curriculum/**").permitAll()
                        .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/disciplines/**").permitAll()
                        .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/coverage/**").permitAll()
                        .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/professions/**").permitAll()
                        .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/skill-canonical/**").permitAll()
                        // Curriculum / Discipline / Coverage - MODIFICATION requires authentication
                        .requestMatchers("/api/curriculum/**").authenticated()
                        .requestMatchers("/api/disciplines/**").authenticated()
                        .requestMatchers("/api/coverage/**").authenticated()
                        .requestMatchers("/api/professions/**").authenticated()
                        .requestMatchers("/api/skill-canonical/**").authenticated()
                        // Static frontend pages
                        .requestMatchers("/*.html", "/static/**", "/css/**", "/js/**", "/images/**").permitAll()
                        .anyRequest().authenticated()
                )
                .authenticationProvider(authenticationProvider())
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
